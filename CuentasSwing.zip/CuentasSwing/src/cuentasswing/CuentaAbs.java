/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cuentasswing;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public abstract class CuentaAbs {
    
        private String numeroCuenta;
        private String titular;
        private double saldo;
        private LocalDate fechaApertura;

    public CuentaAbs(String numeroCuenta, String titular, double saldo, LocalDate fechaApertura) {
        this.numeroCuenta = numeroCuenta;
        this.titular = titular;
        this.saldo = saldo;
        this.fechaApertura = fechaApertura;
    }     

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }      

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }      

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }      

    public LocalDate getFechaApertura() {
        return fechaApertura;
    }

    public void setFechaApertura(LocalDate fechaApertura) {
        this.fechaApertura = fechaApertura;
    }   
    
    public abstract double calcularInteres(double saldo);

}
