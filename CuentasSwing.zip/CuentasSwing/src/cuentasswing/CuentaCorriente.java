/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cuentasswing;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class CuentaCorriente extends CuentaAbs{
    
        private long numTarjCredito;

    public CuentaCorriente(long numTarjCredito, String numeroCuenta, String titular, double saldo, LocalDate fechaApertura) {
        super(numeroCuenta, titular, saldo, fechaApertura);
        this.numTarjCredito = numTarjCredito;
    }         

    public long getNumTarjCredito() {
        return numTarjCredito;
    }

    public void setNumTarjCredito(long numTarjCredito) {
        this.numTarjCredito = numTarjCredito;
    }

    @Override
    public double calcularInteres(double saldo) {
        return (double) saldo * 1.5;
    }
}
