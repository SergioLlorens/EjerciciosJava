/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cuentasswing;

import java.time.LocalDate;
import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class CuentaPlazo extends CuentaAbs {
    
        private int numAños;

    public CuentaPlazo(int numAños, String numeroCuenta, String titular, double saldo, LocalDate fechaApertura) {
        super(numeroCuenta, titular, saldo, fechaApertura);
        this.numAños = numAños;
    }     

    public int getNumAños() {
        return numAños;
    }

    public void setNumAños(int numAños) {
        this.numAños = numAños;
    }

    @Override
    public double calcularInteres(double saldo) {
        return (double) saldo * 3.5;               
    }  

}
