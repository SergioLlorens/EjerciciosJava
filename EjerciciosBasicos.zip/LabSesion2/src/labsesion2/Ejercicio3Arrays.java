/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion2;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Ejercicio3Arrays {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        pedirDatos();
        
    }
    
    public static void pedirDatos(){
        Scanner entrada = new Scanner(System.in);       
        
        int numeroDNI;        
        System.out.print("Introduce tu DNI sin la letra: ");
        numeroDNI = entrada.nextInt();
        
        if ((Integer.toString(numeroDNI).length() > 8)||(Integer.toString(numeroDNI).length() < 8)){
            System.out.println("Los DNI tienen que ser de 8 digitos: No valido");
        }
        else{
            //System.out.println(numeroDNI);
            calcularLetra(numeroDNI);
        }       
    }
    
    public static void calcularLetra(int numeroDNI){      
        char letras[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};        
        int calculo = (numeroDNI % 23);   
        System.out.println("Tu DNI completo es: "+numeroDNI+"-"+letras[calculo]);
        
    }
}
