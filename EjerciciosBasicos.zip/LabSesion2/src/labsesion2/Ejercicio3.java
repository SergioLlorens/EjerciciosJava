/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion2;

import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Ejercicio3 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numero1;
        int numero2;
        
        System.out.println("Introduce el primer numero: ");
        numero1 = entrada.nextInt();
        System.out.println("Introduce el segundo numero: ");
        numero2 = entrada.nextInt();
        
        mayor(numero1,numero2);
        
    }
    
    public static void mayor(int numero1, int numero2){
        if (numero1 > numero2){
            System.out.println("El numero mayor es: "+numero1);            
        }        
        if (numero1 == numero2){
            System.out.println("Los numeros son iguales");
        }
        if (numero2 > numero1){
                System.out.println("El numero mayor es: "+numero2);
            }
        
    }

}
