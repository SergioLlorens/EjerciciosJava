/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion2;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author SERGIO
 */
public class StringTokenizer1 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        String numeroTelefono;
        
        System.out.println("Introduce el numero de telefono. Example 91 8786545: ");
        numeroTelefono = entrada.nextLine();
        
        
        StringTokenizer st = new StringTokenizer(numeroTelefono);
        while(st.hasMoreTokens()){
            //System.out.println(st.nextToken());
            String CComunidad = st.nextToken();
            
            String numero = st.nextToken();
            
            //Convertimos CComunidad a int
            int numeroInt = Integer.parseInt(CComunidad);
            //Convertimos numero a long
            long restoNumero = Long.parseLong(numero);
        
            System.out.println("El prefifo es: "+numeroInt+" Y el telefono: "+restoNumero);
        }
        
        
    }

}
