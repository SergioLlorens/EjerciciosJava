/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labsesion2;

import java.util.Scanner;

/**
 *
 * @author dcc
 */
public class Ejercicio2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        int numero1;
        int numero2;
        
        
        System.out.println("Introduce el menor numero: ");
        numero1 = entrada.nextInt();
        System.out.println("Introduce el mayor numero: ");
        numero2 = entrada.nextInt(); 
        
        rango(numero1, numero2);        
    
    }
    
    public static void rango(int numero1, int numero2){
        for (int i = numero1+1; i < numero2; i++) {            
            //System.out.println(i);
            
            if (esPar(i))
            {
                System.out.println(i);
            }
            
        }        
    }
    
    public static boolean esPar(int i){
        return i%2 == 0;
        
    }   
}
