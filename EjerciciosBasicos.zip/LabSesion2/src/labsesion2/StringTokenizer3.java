/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion2;

import java.util.Scanner;
import java.util.StringTokenizer;

/**
 *
 * @author SERGIO
 */
public class StringTokenizer3 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        String frase;
        
        System.out.println("Introduce una frase: ");
        frase = entrada.nextLine();      
        
        StringBuilder str = new StringBuilder(frase);
        System.out.println("La cadena inversa es: " + str.reverse());
        
        
        /*Pinta la cadena en orden normal de arriba abajo
        StringTokenizer st = new StringTokenizer(frase);
        while(st.hasMoreTokens()){
            System.out.println(st.nextToken());
            
        }
        */
        
        
    }

}
