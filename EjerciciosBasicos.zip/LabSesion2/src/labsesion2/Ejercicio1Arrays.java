/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labsesion2;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author dcc
 */
public class Ejercicio1Arrays {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int numeros[] = new int[100];
        Random rand = new Random();
        char arrays[] = new char[100];
        
        //Generamos numeros aleatorios
        for (int i = 1; i < numeros.length; i++) {
            numeros[i] = rand.nextInt(501);
        }
        
        //Ordenamos el array
        Arrays.sort(numeros);
        
        //System.out.println(Arrays.toString(numeros));
        
        for (int i = 0; i < numeros.length; i++) {
            if (numeros[i]%2 == 0){
                arrays[i]= 'p';                
            }
            else {
                arrays[i]= 'i';                
            }
        }
        
        for (int i = 0; i < 100; i++) {
            if (i % 10==0){
                System.out.println("");          
            }
            System.out.print(" "+numeros[i]+""+arrays[i]);           
        }
        
        
        
        
        
        
    }
    
}
