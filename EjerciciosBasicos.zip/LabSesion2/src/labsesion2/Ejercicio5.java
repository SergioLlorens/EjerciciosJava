/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion2;

import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Ejercicio5 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        double numero1;
        double numero2;
        char caracter;
        
        System.out.println("Introduce el numero 1: ");
        numero1 = entrada.nextInt();
        System.out.println("Introduce el numero 2: ");
        numero2 = entrada.nextInt();
        System.out.println("Introduce el caracter: ");
        caracter = entrada.next().charAt(0);
        
        calculadora(numero1, numero2, caracter);
        
    }
    
    public static void calculadora(double numero1, double numero2, char caracter){
        
        if( caracter == '+'){
            System.out.println("La suma es: "+(numero1+numero2));
        }
        if( caracter == '*'){
            System.out.println("La multiplicacion es: "+(numero1*numero2));
        }
        if( caracter == '-'){
            System.out.println("La resta es: "+(numero1-numero2));
        }
        
    }

}
