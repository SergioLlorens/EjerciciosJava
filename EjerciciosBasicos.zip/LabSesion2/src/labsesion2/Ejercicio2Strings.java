/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion2;

import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Ejercicio2Strings {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        String cadena;
        String letra;
        
        System.out.println("Introduce una palabra: ");
        cadena = entrada.nextLine();
        System.out.println("Introduce una letra: ");
        letra = entrada.nextLine();
        
        System.out.println("Posicion de la letra "+letra+ ": " + cadena.indexOf(letra));      
        
    }

}
