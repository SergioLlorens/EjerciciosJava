/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion2;

import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Ejercicio4Strings {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        
        String DNIcompleto;
        String numeroDNI;
        char letra;
        
        System.out.print("Introduce tu DNI con la letra: ");
        DNIcompleto = entrada.nextLine();
        
        //Cogemos la letra del DNI
        letra = DNIcompleto.charAt(8);
        //System.out.println(letra);
        
        //Cogemos los numeros del DNI
        numeroDNI = DNIcompleto.substring(0,8);
        //System.out.println(numeroDNI); 
        
        //Convertimos el String(numeroDNI) a entero(numeroEntero)
        int numeroEntero = Integer.parseInt(numeroDNI);    
        
        if ((Integer.toString(numeroEntero).length() > 8) && (Integer.toString(numeroEntero).length() < 8)){
            System.out.println("Los DNI tienen que ser de 8 digitos: No valido");
        }
        else{
            //System.out.println(numeroDNI);
            calcularLetra(numeroEntero, letra);
        }       
    }
    
    public static void calcularLetra(int numeroEntero, char letra){      
        char letras[] = {'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E'};        
        int calculo = (numeroEntero % 23);
        char solucion;       
       
        //En solucion guardamos la letra correcta
        solucion = letras[calculo];
        
        //Comparamos la letra correcta con la introducida
        if(solucion == letra){
            System.out.println("DNI CORRECTO");
        }
        else{
            System.out.println("DNI INCORRECTO, la letra deberia de ser: "+solucion);
        }       
    }        
}


