/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package labsesion2;

import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author dcc
 */
public class Ejercicio2Arrays {
    
    public static void main(String[] args) {       
        
        char letras[] = new char[50];
        Random rand = new Random();
        int contador = 0;
        
        
        //Generamos numeros aleatorios
        for (int i = 0; i < letras.length; i++) {
            letras[i] = (char)(97+rand.nextInt(26));            
        }
        
        //Ordenamos el array
        Arrays.sort(letras);
        
        System.out.println(Arrays.toString(letras));        
        
        
        for (int i = 0; i < letras.length; i++) {
            if (letras[i] == 'a' || letras[i] == 'e' || letras[i] == 'i' || letras[i] == 'o' || letras[i] == 'u'){
                contador +=1;                
            }
            
        }
        System.out.println("Hay "+contador+" vocales");
    
    }
    
    
    
}
