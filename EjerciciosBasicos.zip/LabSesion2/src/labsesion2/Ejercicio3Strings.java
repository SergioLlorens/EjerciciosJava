/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion2;

import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Ejercicio3Strings {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        String cadena;
        int ContadorTotalVocales = 0;
        int ContadorA = 0;
        int ContadorE = 0;
        int ContadorI = 0;
        int ContadorO = 0;
        int ContadorU = 0;
        
        System.out.println("Introduce una palabra: ");
        cadena = entrada.nextLine();
        cadena = cadena.toLowerCase();                             //Convierto la cadena a minusculas
        
        for (int i = 0; i < cadena.length(); i++) {
            if((cadena.charAt(i)=='a') || (cadena.charAt(i)=='e') || (cadena.charAt(i)=='i') || (cadena.charAt(i)=='o') || (cadena.charAt(i)=='u')){
                ContadorTotalVocales++;
            }           
        }
        System.out.println("Numero Total de vocales: "+ContadorTotalVocales);
        
        for (int i = 0; i < cadena.length(); i++) {
            if(cadena.charAt(i)=='a'){
                ContadorA++;
            }
            if(cadena.charAt(i)=='e'){
                ContadorE++;
            }
            if(cadena.charAt(i)=='i'){
                ContadorI++;
            }
            if(cadena.charAt(i)=='o'){
                ContadorO++;
            }
            if(cadena.charAt(i)=='u'){
                ContadorU++;
            }
        }        
        System.out.println("Veces que se repiten las vocales:\n La a: "+ContadorA+" veces.\n La e: "+ContadorE+" veces.\n La i: "+ContadorI+" veces.\n La o: "+ContadorO+" veces.\n La u: "+ContadorU+" veces");
        
        
        
        
        
    }

}
