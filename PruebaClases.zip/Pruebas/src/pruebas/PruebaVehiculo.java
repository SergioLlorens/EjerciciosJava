/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

/**
 *
 * @author SERGIO
 */
public class PruebaVehiculo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Moto m1 = new Moto(2, "BMW", "R1", 200, 280);        
        System.out.println(m1.arrancar(m1));
        
        Coche c1 = new Coche(true, 1500, "Mercedes", "Clase A", 150, 250 );
        System.out.println(c1.parar(c1));
        
        Coche c2 = new Coche(false, 950, "Opel", "Corsa", 95, 20 );
        Coche c3 = new Coche(false, 500, "Audi", "A1", 200, 130 );
        
        System.out.println(c2.aparcar(c2));
        System.out.println(c3.aparcar(c3));
        System.out.println("Vehiculos: "+ Vehiculo.getMarcaCoches());
        
        
        
        
        
      
        
         
        
        
    }
    
}
