/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pruebas;

import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Moto extends Vehiculo {
    
        public int ruedas;

    public Moto(int ruedas, String marca, String Modelo, int Cv, int velocidad) {
        super(marca, Modelo, Cv, velocidad);
        this.ruedas = ruedas;
    }      

    public int getRuedas() {
        return ruedas;
    }

    public void setRuedas(int ruedas) {
        this.ruedas = ruedas;
    }  

}
