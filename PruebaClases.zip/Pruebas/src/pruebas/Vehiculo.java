/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pruebas;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Vehiculo {
    
    private String marca;
    private String Modelo;
    private int Cv;
    private int velocidad;
    static ArrayList<Vehiculo> aparcamiento = new ArrayList<Vehiculo>();
    
    

    public Vehiculo(String marca, String Modelo, int Cv, int velocidad) {
        this.marca = marca;
        this.Modelo = Modelo;
        this.Cv = Cv;
        this.velocidad = velocidad;
    }  

    public String getMarca() {
        return marca;
    }
    
    public void setMarca(String marca) {
        this.marca = marca;
    }       

    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }       

    public int getCv() {
        return Cv;
    }

    public void setCv(int Cv) {
        this.Cv = Cv;
    }
    
    public int getvelocidad() {
        return velocidad;
    }

    public void setvelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
    
    public String arrancar(Object m){
        String dato = "";
        if (this.velocidad > 0){
            dato = "vehiculo en marcha";
        } else {
            dato = "vehiculo parado";
        }       
        return dato;
    }
    
    public String parar(Object m){
        String dato = "";
        if (this.velocidad > 0){
            dato = "El vehiculo ha sido parado";
        } else {
            dato = "El vehiculo ya estaba parado";
        }
        return dato;
            
    }   
     
     public static ArrayList<String> getMarcaCoches(){
        ArrayList<String> marcas = new ArrayList<>();
        for (Vehiculo v : aparcamiento) {
            marcas.add(v.getMarca());            
        }
        return marcas;
    }     
     
    public String aparcar(Vehiculo v){
        aparcamiento.add(v);      
        return "Numero de coches aparcados: " + aparcamiento.size();
    } 
    
    
    
}
