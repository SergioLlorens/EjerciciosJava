/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package lampara;

//import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Lampara {
    
    //Constructor
    public Lampara(boolean encendida, int intensidad, double voltaje) {        
        this.encendida = encendida;
        this.intensidad = intensidad;
        this.voltaje = voltaje;
    }  
    
        private double voltaje;

    public double getVoltaje() {
        return voltaje;
    }

    public void setVoltaje(double voltaje) {
        this.voltaje = voltaje;
    }

    
        private boolean encendida;

    public boolean isEncendida() {
        return encendida;
    }

    public String setEncendida(int intensidad) {
        String luz;
        if (intensidad > 0){
            luz = "ON";
        } 
        else {
            luz = "OFF";
        }
        
        return luz;
              
    }    

    private int intensidad;

    public int getIntensidad() {
        return intensidad;
    }

    public void setIntensidad(int intensidad) {
        this.intensidad = intensidad;
    }
    
    public double setIntensidad(double voltaje) {
        
        if (voltaje >= 12.5){
            intensidad = 100;
        }
        if (voltaje <= 1.5){
            intensidad = 0;
        }
        if ((voltaje > 1.5) && (voltaje < 12.5)){
            double regla3 = (voltaje*100)/12.5;
            intensidad = (int) regla3;
        }
       return intensidad;
    }   
    
            
    
    @Override
    public String toString(){
        int valorEnc =  (int) setIntensidad(this.voltaje);
        return "La luz esta: "+ setEncendida(valorEnc) + " y la intensidad en: " + setIntensidad(this.voltaje) + " con un voltaje de "+voltaje; 
    }  
}
