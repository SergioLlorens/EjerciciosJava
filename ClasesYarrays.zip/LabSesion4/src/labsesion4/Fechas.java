/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package labsesion4;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

/**
 *
 * @author SERGIO
 */
public class Fechas {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        
        LocalDateTime hoy = LocalDateTime.now();
        System.out.println("La fecha de hoy es: "+hoy);
        
        //Cambiamos el formato
        DateTimeFormatter formatoCorto = DateTimeFormatter.ofPattern("dd/MM/yyyy:HH/:mm");
        System.out.println("Hoy es (formato corto): "+ hoy.format(formatoCorto));
        
        //Establecemos una fecha
        LocalDateTime diaHora = LocalDateTime.of(2010, Month.FEBRUARY, 25, 10, 59, 59);
        System.out.println("La fecha establecida: " + diaHora);
        diaHora = diaHora.plusMonths(1).minusDays(5).minusHours(3);
        System.out.println("La fecha modificada: " + diaHora);        
        
        //diferencia entre fechas
        long dias = ChronoUnit.DAYS.between(diaHora, hoy);
        System.out.println("días: " + dias);
        
        
        
        
        
        
        
        
        
    }

}
