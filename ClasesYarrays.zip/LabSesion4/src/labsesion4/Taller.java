/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller;

import java.util.ArrayList;

/**
 *
 * @author dcc
 */
public class Taller {

    public Taller(String nombre, String telefono, double precio_hora) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.precio_hora = precio_hora;
    }
    
    private String nombre;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    private String telefono;

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    private double precio_hora;

    public double getPrecio_hora() {
        return precio_hora;
    }

    public void setPrecio_hora(double precio_hora) {
        this.precio_hora = precio_hora;
    }

    void repararVehiculo(Vehiculo vehiculo,int hora){
        double cuentaInicial = precio_hora * hora;
        ArrayList<Pieza> piezasVehiculo = vehiculo.PiezasArregladas;
        double precio = 0;
        for (int i = 0; i < piezasVehiculo.size(); i++) {
            Pieza p = piezasVehiculo.get(i);
         
            double precioP = p.getPrecio();
            precio = precioP + precio;
            
        }
                
        
        double sumaFinal = cuentaInicial + precio;
        System.out.println("El precio final es: " + sumaFinal);
        
    }
    
}
