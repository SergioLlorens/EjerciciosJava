/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller;

/**
 *
 * @author dcc
 */
public class PruebaTaller {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Taller taller1 = new Taller ("TalleresPaco", "91354621", 9.5);
        
        Pieza pieza1 = new Pieza("Carburador", 150);
        Pieza pieza2 = new Pieza("Aleron", 250);
        
        Vehiculo v1 = new Vehiculo("KKK 999", "Ford", "Mustang");        
        v1.PiezasArregladas.add(pieza1);
        v1.PiezasArregladas.add(pieza2);
        
            
        
        Vehiculo v2 = new Vehiculo("999 ABD", "Nissan", "GTR");
        
        taller1.repararVehiculo(v1,5);
        
    }

    
    
}
